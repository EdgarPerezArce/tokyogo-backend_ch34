me = {
    "name": "Edgar",
    "last": "Perez",
    "age": 34,
    "hobbies":["fishing", "gaming", "art"],
    "address": {
        "number":40,
        "street":"darby",
        "city": "kissimmee",
        "zip": "34743",
        




    }
}